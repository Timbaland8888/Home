# coding=utf-8

# app_label = ''
verbose_name = u'示例App'

menus = (
         # ('test_group', u'Pages', 'test_icon'),
         )