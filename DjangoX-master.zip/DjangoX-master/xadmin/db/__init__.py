# -*- coding: utf-8 -*-

from .query import Collection, Q

__all__ = ["Collection", "Q"]

