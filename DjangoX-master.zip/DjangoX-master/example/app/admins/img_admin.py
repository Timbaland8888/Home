# coding=utf-8

import xadmin

from app import models

xadmin.site.register(models.TestImg)