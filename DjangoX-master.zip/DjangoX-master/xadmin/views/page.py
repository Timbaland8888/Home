# coding=utf-8

from custom_page import PageView
from custom_list import GridPage
from custom_form import FormPage, FormAction, ConfigFormPage
