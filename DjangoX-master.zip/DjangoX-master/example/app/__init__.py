# -*- coding: utf-8 -*-

verbose_name = u'示例App'

menus = (
         ('test_group', u'Pages', 'fa fa-reorder'),
         )
