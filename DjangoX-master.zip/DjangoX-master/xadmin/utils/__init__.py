# coding=utf-8

def fa_icon(name):
    '''
    http://fontawesome.dashgame.com/
    '''
    return 'fa fa-%s'%name